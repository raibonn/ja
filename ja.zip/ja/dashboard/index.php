<?php

return [
    'search' => 'サーバーを検索する...',
    'no_matches' => '検索条件に一致するサーバーは見つかりませんでした。',
    'cpu_title' => 'CPU',
    'memory_title' => 'メモリー',
];
